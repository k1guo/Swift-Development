//
//  NotesScreenProtocol.swift
//  WA7_<Guo>_<7669>
//
//  Created by 郭 on 2023/10/27.
//

import Foundation

protocol NotesScreenProtocol{
    func apiLogOut()
    func getAllNotes(key:String)
    func apiAddANewNotes(key:String,text:String)
    func apiDeleteNote(id:String,rowInt:Int,key:String)
}
