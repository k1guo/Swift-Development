//
//  APIConfigs.swift
//  WA7_<Guo>_<7669>
//
//  Created by 郭 on 2023/10/26.
//

import Foundation

class APIConfigs{
    static let baseNoteURL = "http://apis.sakibnm.space:3000/api/note/"
    static let baseAuthURL = "http://apis.sakibnm.space:3000/api/auth/"
}

