//
//  ProfileScreenController.swift
//  WA7_<Guo>_<7669>
//
//  Created by 郭 on 2023/10/27.
//

import UIKit
import Alamofire

class ProfileScreenController: UIViewController {
    
    let profileScreen = ProfileScreen()
    
    let loginScreen = ViewController()

    override func loadView() {
        view = profileScreen
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        NotificationCenter.default.addObserver(self, selector: #selector(appWillEnter), name: UIApplication.willEnterForegroundNotification, object: nil)
        
        let apiKeySaved = loginScreen.defaults.object(forKey: "apiKey") as! String?
       
        if let apiKey = apiKeySaved{

            print("The Saved API Key: \(apiKey)")
            
            apiGetMeDetail(key:apiKey)

        }else{
            print("No API Key saved at the moment!")
        }
    }
    
    @objc func appWillEnter() {
        let apiKeySaved = loginScreen.defaults.object(forKey: "apiKey") as! String?
        if let apiKey = apiKeySaved{
            self.loadView()
        }else{
            self.navigationController?.popToRootViewController(animated: true)
            print("No API Key saved at the moment!")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
