//
//  SignUpController.swift
//  WA7_<Guo>_<7669>
//
//  Created by 郭 on 2023/10/26.
//

import UIKit
import Alamofire


class SignUpController: UIViewController {
    
    let signUpScreen = SignUpScreen()
    
    let notesScreen = NotesScreenController()
    
    override func loadView() {
        view = signUpScreen
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        signUpScreen.buttonSignUp.addTarget(self, action: #selector(buttonSignUpTaped), for: .touchUpInside)
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    @objc func buttonSignUpTaped(){
        if let name = signUpScreen.textFieldName.text,
           let email = signUpScreen.textFieldEmail.text,
           let password = signUpScreen.textFieldPassword.text{
            if !name.isEmpty && !email.isEmpty && !password.isEmpty{
                if !isValidEmail(email){
                    showAlertText(text:"please enter valid email~~")
                }
                let user = RegisterInfo(name: name, email: email, password:password)
                createANewUser(registerInfo: user)
            }else{
                showAlertText(text:"please enter all information~~")
            }
        }
    }
    func showAlertText(text:String){
        let alert = UIAlertController(
            title: "Error!",
            message: "\(text)",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true)
    }
}

