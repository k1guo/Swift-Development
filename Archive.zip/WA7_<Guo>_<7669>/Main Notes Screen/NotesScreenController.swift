//
//  NotesScreenController.swift
//  WA7_<Guo>_<7669>
//
//  Created by 郭 on 2023/10/26.
//

import UIKit
import Alamofire

class NotesScreenController: UIViewController {

    let notesScreen = NotesScreen()
    
    var notesList = [String]()
    
    var allNotes = [noteInfo]()
    
    let loginScreen = ViewController()
    
    var key = String()
    
    override func loadView() {
        view = notesScreen
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notesScreen.tableViewNotes.dataSource = self
        notesScreen.tableViewNotes.delegate = self
        notesScreen.tableViewNotes.separatorStyle = .none
        
        getKey()
        getAllNotes(key: key)
        NotificationCenter.default.addObserver(self, selector: #selector(appWillEnter), name: UIApplication.willEnterForegroundNotification, object: nil)

        notesScreen.buttonAdd.addTarget(self, action: #selector(buttonAddTaped), for: .touchUpInside)
        navigationItem.rightBarButtonItem = UIBarButtonItem()
        navigationItem.rightBarButtonItem?.title = "More"
        navigationItem.rightBarButtonItem?.menu = UIMenu(title: "Setting",
                                                         children: [
                                                             UIAction(title: "My Profile",handler: {(_) in
                                                                 self.showMyProfile()
                                                             }),
                                                             UIAction(title: "Log Out",handler: {(_) in
                                                                 self.userLogOut()
                                                             })
                                                         ])
        
    }
    
    @objc func appWillEnter() {
        let apiKeySaved = loginScreen.defaults.object(forKey: "apiKey") as! String?
        if let apiKey = apiKeySaved{
            self.loadView()
        }else{
            self.navigationController?.popToRootViewController(animated: true)
            print("No API Key saved at the moment!")
        }
    }
    
    
    func  userLogOut(){
        let alert = UIAlertController(title: "Exit Alert!", message: "Are you sure you want to exit the Notes ?", preferredStyle: .alert)

        let action = UIAlertAction(title:  "Yes", style: .cancel) { [] (action) in
            print(self.key,"key in here")
            self.apiLogOut()
        }
        alert.addAction(action)
        alert.addAction(UIAlertAction(title: "No", style: .default))
        self.present(alert, animated: true)
    }
    
    
    func  showMyProfile(){
        let profileScreen = ProfileScreenController()
        navigationController?.pushViewController(profileScreen, animated:true)
    }
    
   
    func getKey(){
        let apiKeySaved = loginScreen.defaults.object(forKey: "apiKey") as! String?
        if let apiKey = apiKeySaved{
            print("The Saved API Key: \(apiKey)")
            self.key = apiKey
        }else{
            print("No API Key saved at the moment!")
        }
    }
    

    @objc func buttonAddTaped(){
        let note = notesScreen.textFieldAddNote.text
        if let uwNote = note{
            if !uwNote.isEmpty{
                
                apiAddANewNotes(key:key,text:uwNote)
            }else{
                showAlertText(text:"Note can not be empty")
            }
        }
    }
    

    func editSelectedFor(){
        
    }
    
    
    func deleteSelectedFor(id:String,rowInt:Int){
        let deleteAlert = UIAlertController(title: "Delete Alert!", message: "Are you sure you want to delete the contact ?", preferredStyle: .alert)

        let deleteAction = UIAlertAction(title:  "Sure", style: .cancel) { [self] (action) in
            apiDeleteNote(id:id,rowInt:rowInt,key:key)
        }

        deleteAlert.addAction(deleteAction)
        deleteAlert.addAction(UIAlertAction(title: "Recall", style: .default))
        self.present(deleteAlert, animated: true)
    }
    
    
    func showAlertText(text:String){
        let alert = UIAlertController(
            title: "Error",
            message: "\(text)",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true)
    }
}


extension NotesScreenController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allNotes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notes", for: indexPath) as! NoteTableViewCell
        print(self.allNotes[indexPath.row].text)
        
        cell.labelName.text = self.allNotes[indexPath.row].text

        let buttonOptions = UIButton(type: .system)
        buttonOptions.sizeToFit()
        buttonOptions.showsMenuAsPrimaryAction = true
        buttonOptions.setImage(UIImage(systemName: "slider.horizontal.3"), for: .normal)
        buttonOptions.menu = UIMenu(title: "Edit/Delete?",
                                    children: [
                                        UIAction(title: "Edit",handler: {(_) in
                                            self.editSelectedFor()
                                        }),
                                        UIAction(title: "Delete",handler: {(_) in
                                            self.deleteSelectedFor(id: self.allNotes[indexPath.row]._id,rowInt:indexPath.row)
                                        })
                                    ])
        cell.accessoryView = buttonOptions

        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        getContactDetails(name: self.notesList[indexPath.row])
        
        
    }
}


