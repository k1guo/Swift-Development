//
//  NotesScreen.swift
//  WA7_<Guo>_<7669>
//
//  Created by 郭 on 2023/10/26.
//

import UIKit

class NotesScreen: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    var labelDisplayNotes:UILabel!
    var contentWrapper:UIScrollView!
    var tableViewNotes: UITableView!
    var bottomAddView:UIView!
    var textFieldAddNote:UITextView!
    var buttonAdd:UIButton!

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        
        setupLabelDisplayNotes()
        setupContentWrapper()
        setupTableViewNotes()
        setupBottomAddView()
        setupTextFieldAddNote()
        setupButtonAdd()

        initConstraints()
    }
    
    func setupBottomAddView(){
        bottomAddView = UIView()
        bottomAddView.backgroundColor = .white
        bottomAddView.layer.cornerRadius = 10
        bottomAddView.layer.shadowColor = UIColor.lightGray.cgColor
        bottomAddView.layer.shadowOffset = .zero
        bottomAddView.layer.shadowRadius = 4.0
        bottomAddView.layer.shadowOpacity = 0.7
        bottomAddView.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(bottomAddView)
    }
    func setupTextFieldAddNote(){
        textFieldAddNote = UITextView(frame:CGRectMake(50, 50, 50, 50))
        textFieldAddNote.layer.cornerRadius = 10
        textFieldAddNote.layer.backgroundColor = UIColor.lightGray.cgColor
        textFieldAddNote.text = "Enter.."
        textFieldAddNote.font = UIFont.systemFont(ofSize:18)
        
        textFieldAddNote.translatesAutoresizingMaskIntoConstraints = false
        bottomAddView.addSubview(textFieldAddNote)
    }
    func setupLabelDisplayNotes(){
        labelDisplayNotes = UILabel()
        labelDisplayNotes.text = "Display Notes"
        labelDisplayNotes.font = UIFont.boldSystemFont(ofSize: 35)
        labelDisplayNotes.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(labelDisplayNotes)
    }
    func setupContentWrapper(){
        contentWrapper = UIScrollView()
        contentWrapper.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(contentWrapper)
    }
    func setupTableViewNotes(){
        tableViewNotes = UITableView()
        tableViewNotes.register(NoteTableViewCell.self, forCellReuseIdentifier: "notes")
        tableViewNotes.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(tableViewNotes)
    }
    func setupButtonAdd(){
        buttonAdd = UIButton(type: .system)
        buttonAdd.titleLabel?.font = .boldSystemFont(ofSize: 16)
        buttonAdd.setTitle("Add Note", for: .normal)
        buttonAdd.translatesAutoresizingMaskIntoConstraints = false
        bottomAddView.addSubview(buttonAdd)
    }
    func initConstraints(){
        NSLayoutConstraint.activate([
            labelDisplayNotes.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor, constant: 12),
            labelDisplayNotes.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            
            bottomAddView.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor,constant: -8),
            bottomAddView.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 8),
            bottomAddView.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -8),
            
            buttonAdd.bottomAnchor.constraint(equalTo: bottomAddView.bottomAnchor, constant: -8),
            buttonAdd.leadingAnchor.constraint(equalTo: bottomAddView.leadingAnchor, constant: 4),
            buttonAdd.trailingAnchor.constraint(equalTo: bottomAddView.trailingAnchor, constant: -4),
            
            textFieldAddNote.bottomAnchor.constraint(equalTo: buttonAdd.topAnchor, constant: -8),
            textFieldAddNote.leadingAnchor.constraint(equalTo: buttonAdd.leadingAnchor, constant: 4),
            textFieldAddNote.trailingAnchor.constraint(equalTo: buttonAdd.trailingAnchor, constant: -4),
            textFieldAddNote.heightAnchor.constraint(equalToConstant: 150),
            
            bottomAddView.topAnchor.constraint(equalTo: textFieldAddNote.topAnchor, constant: -8),
            
            tableViewNotes.topAnchor.constraint(equalTo: labelDisplayNotes.bottomAnchor, constant: 32),
            tableViewNotes.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 8),
            tableViewNotes.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -8),
            tableViewNotes.bottomAnchor.constraint(equalTo: bottomAddView.topAnchor, constant: -8),
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
