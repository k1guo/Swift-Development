//
//  DisplayNotes.swift
//  WA7_<Guo>_<7669>
//
//  Created by 郭 on 2023/10/26.
//

import Foundation

struct Note{
    let name:String
}

struct Notes{
    let notesList: [Note]
}
